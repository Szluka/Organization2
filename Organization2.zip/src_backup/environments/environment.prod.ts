export const environment = {

  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyBf2SL7zxdnFFddTJT_zWakTIqoFvRjCIQ",
    authDomain: "organization3-7553c.firebaseapp.com",
    projectId: "organization3-7553c",
    storageBucket: "organization3-7553c.appspot.com",
    messagingSenderId: "603826240062",
    appId: "1:603826240062:web:65ad9185acf0d2ad52ef6f"
  }
};
