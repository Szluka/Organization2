import {Coding} from './Coding.model';

export interface CodeableConcept {
  codin?: Coding;
  text?: string;
}
